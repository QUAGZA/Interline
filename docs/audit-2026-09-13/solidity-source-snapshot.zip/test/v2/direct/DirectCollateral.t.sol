// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {DirectFixture} from "../fixtures/DirectFixture.sol";
import {DirectCreditFacility} from "../../../src/v2/direct/DirectCreditFacility.sol";

contract DirectCollateralTest is DirectFixture {
    DirectCreditFacility internal fac;

    function setUp() public {
        _deployDirectStack();
        fac = _create(alice, _terms(alice, bob));
        _accept(fac, bob);
        _fundLender(fac, alice, 5_000e6);
    }

    function test_BorrowWithoutCollateralReverts() public {
        vm.prank(bob);
        vm.expectRevert(DirectCreditFacility.InsufficientCollateral.selector);
        fac.borrow(10e6, type(uint256).max, block.timestamp + 1);
    }

    function test_BorrowCappedAtEightyPercentOfCollateral() public {
        _postCollateral(fac, bob, 1 ether);
        vm.startPrank(bob);
        fac.borrow(1_600e6, type(uint256).max, block.timestamp + 1);
        vm.expectRevert(DirectCreditFacility.InsufficientCollateral.selector);
        fac.borrow(1, type(uint256).max, block.timestamp + 1);
        vm.stopPrank();
        assertEq(fac.currentDebt(), 1_600e6);
        assertEq(fac.availableToBorrow(), 0);
    }

    function test_RemoveCollateralKeepsEightyPercentLtv() public {
        _postCollateral(fac, bob, 2 ether);
        vm.prank(bob);
        fac.borrow(1_600e6, type(uint256).max, block.timestamp + 1);
        vm.prank(bob);
        fac.removeCollateral(1 ether);
        vm.prank(bob);
        vm.expectRevert(DirectCreditFacility.InsufficientCollateral.selector);
        fac.removeCollateral(1);
    }
}

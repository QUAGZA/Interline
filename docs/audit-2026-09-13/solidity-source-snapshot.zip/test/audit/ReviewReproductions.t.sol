// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// Audit evidence: these tests assert CURRENT DEFECTIVE behavior, not desired behavior.
// Replace the assertions with prevention/regression assertions when the defects are fixed.
import {RestrictedFixture} from "../v2/fixtures/RestrictedFixture.sol";
import {BorrowerVaultV2} from "../../src/v2/BorrowerVaultV2.sol";

contract PoolAuditReproductions is RestrictedFixture {
    function setUp() public { _deployRestricted(); }

    function test_AUDIT_ExactCollateralSeizesMoreThanFivePercentBonus() public {
        _fund(alice, 10_000e6, 0);
        _fund(bob, 0, 1 ether);
        _fund(carol, 10_000e6, 0);
        _supply(alice, 10_000e6);
        _collateral(bob, 1 ether);
        _borrow(bob, 1_400e6);
        wethFeed.setAnswer(1_550e8);
        uint256 beforeLoan = musdc.balanceOf(carol);
        vm.prank(carol);
        market.liquidate(bob, 0, 1 ether, type(uint256).max, 0);
        assertEq(beforeLoan - musdc.balanceOf(carol), 1_400e6);
        assertEq(mweth.balanceOf(carol), 1 ether);
        assertEq(market.collateralOf(bob), 0);
        // $1,550 seized for $1,400: $150 bonus instead of $70.
        assertGt(uint256(1_550e6), (uint256(1_400e6) * 10_500) / 10_000);
    }

    function test_AUDIT_CuratorChangesCapWithoutBorrowerConsent() public {
        uint256 expiry = block.timestamp + 1 days;
        bytes32 salt = keccak256("unilateral");
        vm.startPrank(curator);
        restricted.proposeCap(bob, 10e6, 0, expiry, salt);
        restricted.approveCap(restricted.hashCapProposal(bob, 10e6, 0, expiry, salt));
        restricted.executeCap(bob, 10e6, 0, expiry, salt);
        vm.stopPrank();
        assertEq(restricted.positionCapOf(bob), 10e6);
    }

    function test_AUDIT_SiblingProposalExecutesAfterNonceConsumed() public {
        uint256 expiry = block.timestamp + 1 days;
        bytes32 a = keccak256("a");
        bytes32 b = keccak256("b");
        vm.startPrank(bob);
        restricted.proposeCap(bob, 30_000e6, 0, expiry, a);
        restricted.proposeCap(bob, 40_000e6, 0, expiry, b);
        vm.stopPrank();
        vm.startPrank(curator);
        restricted.approveCap(restricted.hashCapProposal(bob, 30_000e6, 0, expiry, a));
        restricted.approveCap(restricted.hashCapProposal(bob, 40_000e6, 0, expiry, b));
        vm.stopPrank();
        restricted.executeCap(bob, 30_000e6, 0, expiry, a);
        assertEq(restricted.capNonce(bob), 1);
        restricted.executeCap(bob, 40_000e6, 0, expiry, b);
        assertEq(restricted.capNonce(bob), 2);
        assertEq(restricted.positionCapOf(bob), 40_000e6);
    }

    function test_AUDIT_RecoveryExceedsWrittenOffDebtAndNeverClears() public {
        BorrowerVaultV2 vault = _openRestrictedBorrow(alice, bob, 10_000e6, 1 ether, 1_400e6);
        _writeOffBob(vault);
        uint256 obligation = restricted.recoveryObligation(bob);
        uint256 episode = escrow.latestEpisodeOf(address(restricted), bob);
        uint256 beforeClaim = escrow.claimable(episode, alice);
        vault.recoverIdleToEscrow();
        assertEq(escrow.claimable(episode, alice) - beforeClaim, 1_400e6);
        assertGt(1_400e6, obligation);
        assertEq(restricted.recoveryObligation(bob), obligation);
        assertTrue(restricted.isDefaulted(bob));
    }
}

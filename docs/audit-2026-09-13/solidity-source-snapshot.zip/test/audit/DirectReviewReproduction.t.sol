// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
// Audit evidence: asserts current defective behavior, not a prevention regression.
import {DirectFixture} from "../v2/fixtures/DirectFixture.sol";
import {DirectCreditFacility} from "../../src/v2/direct/DirectCreditFacility.sol";
import {IDirectCreditFacility} from "../../src/v2/direct/interfaces/IDirectCreditFacility.sol";
import {BorrowerVaultV2} from "../../src/v2/BorrowerVaultV2.sol";

contract DirectAuditReproductions is DirectFixture {
    function setUp() public { _deployDirectStack(); }

    function test_AUDIT_RecallCanDelayEarlierMaturityRecovery() public {
        IDirectCreditFacility.Terms memory t = _terms(alice, bob);
        t.borrowPeriod = 1 days;
        DirectCreditFacility fac = _create(alice, t);
        _accept(fac, bob);
        _postCollateral(fac, bob, 1 ether);
        _fundLender(fac, alice, 1_000e6);
        vm.prank(bob);
        fac.borrow(500e6, type(uint256).max, block.timestamp + 100);
        BorrowerVaultV2 vault = BorrowerVaultV2(fac.vault());
        vm.prank(bob);
        vault.enterVenue(500e6, 0);
        uint256 maturity = fac.repaymentDueAt();
        vm.warp(maturity - 100);
        vm.prank(alice);
        fac.requestRepayment(1);
        vm.warp(maturity + 1);
        assertGt(fac.recallDeadline(), maturity);
        vm.prank(carol);
        vm.expectRevert(BorrowerVaultV2.RecallWindowOpen.selector);
        fac.recoverVenue(500e6, type(uint256).max);
    }
}
